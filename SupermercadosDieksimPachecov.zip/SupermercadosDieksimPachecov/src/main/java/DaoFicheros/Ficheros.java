package DaoFicheros;

import Common.Configuracion;
import Domain.Cliente;
import Domain.Empleado;
import Domain.Factura;
import Domain.Producto;
import Service.InterfazGestion;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import lombok.extern.log4j.Log4j2;
import java.io.*;
import java.lang.reflect.Type;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;


@Log4j2
public class Ficheros {


    public static void escribirFicheroClientes(Set<Cliente> listaClientes) throws FileNotFoundException {
        PrintWriter pr = new PrintWriter(new Configuracion().loadPathProperties("pathClientes"));
        listaClientes.forEach(empleado -> pr.println(empleado.toStringFicheros()));
        pr.close();

    }


    public static void ecribirFicheroEmpleado(Set<Empleado> listaEmpleados) throws FileNotFoundException {

        ArrayList<Empleado> listaEmpleadosList = new ArrayList<>(listaEmpleados);

        PrintWriter pr = new PrintWriter("Empleados");
        listaEmpleadosList.forEach(empleado -> pr.println(empleado.toStringFicheros()));
        pr.close();

    }


    public static void escribirFicheroProductosBinario(List<Producto> productos) throws IOException {

        ObjectOutputStream obs = new ObjectOutputStream(new FileOutputStream("Productos"));
        productos.forEach(producto -> {
            try {
                obs.writeObject(producto);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

    }


    public static void reescribirTodosLosFicheros(InterfazGestion service) {
        try {
            ecribirFicheroEmpleado(service.getDaoEmpleados().getDaoEmpleados().getEmpleados());
            escribirFicherosFactura(service.getDaoFacturas().getDaoFacturas().getFacturas());
            escribirFicheroProductosBinario(service.getDaoProductos().getDaoProductos().getProductos());
            escribirFicheroClientes(service.getDaoClientes().getDaoClientes().getClientes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    public static HashSet<Empleado> leerFicheroEmpleado() {

        Scanner lector = null;
        try {
            lector = new Scanner(new File("Empleados"));
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        HashSet<Empleado> empleados = new HashSet<>();

        while (lector.hasNextLine()) {
            empleados.add(new Empleado(lector.nextLine()));
        }

        return empleados;
    }

    public static Set<Cliente> leerFicheroCliente() throws FileNotFoundException {


        Scanner lector = new Scanner(new File("Clientes"));

        Set<Cliente> clientes = new TreeSet<>();

        while (lector.hasNextLine()) {
            clientes.add(new Cliente(lector.nextLine()));
        }

        return clientes;
    }

    public static List<Producto> leerFicheroProductosBinario() {
        List<Producto> productos = new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("Productos"))) {
            Object obj;
            while ((obj = ois.readObject()) != null) {
                if (obj instanceof Producto) {
                    productos.add((Producto) obj);
                }
            }
        } catch (EOFException eof) {
            log.info("Fin del archivo alcanzado.");
        } catch (IOException | ClassNotFoundException e) {
            log.error("Error al leer el archivo: " + e.getMessage());
        }
        return productos;
    }


    public static List<Factura> leerFicheroFacturas() {

        GsonBuilder gsonBuilder = new GsonBuilder();

        gsonBuilder.registerTypeAdapter(LocalDate.class, new LocalDateSerializer());

        gsonBuilder.registerTypeAdapter(LocalDateTime.class, new LocalDateTimeSerializer());

        gsonBuilder.registerTypeAdapter(LocalDate.class, new LocalDateDeserializer());

        gsonBuilder.registerTypeAdapter(LocalDateTime.class, new LocalDateTimeDeserializer());

        Gson gson = gsonBuilder.setPrettyPrinting().create();

        Type userListType = new TypeToken<ArrayList<Factura>>() {
        }.getType();
        log.info("Cargando facturas");
        List<Factura> facturas = null;
        try {
            facturas = gson.fromJson(
                    new FileReader(new Configuracion().loadPathProperties("pathFacturas")),
                    userListType);
        } catch (FileNotFoundException e) {
            log.error(e.getMessage(), e);
        }
        return facturas;
    }

    public static void escribirFicherosFactura(List<Factura> facturas) {

        GsonBuilder gsonBuilder = new GsonBuilder();

        gsonBuilder.registerTypeAdapter(LocalDate.class, new LocalDateSerializer());

        gsonBuilder.registerTypeAdapter(LocalDateTime.class, new LocalDateTimeSerializer());

        gsonBuilder.registerTypeAdapter(LocalDate.class, new LocalDateDeserializer());

        gsonBuilder.registerTypeAdapter(LocalDateTime.class, new LocalDateTimeDeserializer());

        Gson gson = gsonBuilder.setPrettyPrinting().create();


        try (FileWriter fw = new FileWriter(new Configuracion().loadPathProperties("pathFacturas"))) {
            gson.toJson(facturas, fw);
        } catch (IOException e) {
            log.error(e.getMessage(), e);

        }
    }


}
