package Common;

public class Constantes {

    public static final String[] NOMBRES = {
            "Juan Pérez", "María García", "Pedro Martínez", "Ana López", "Luis Rodríguez", "Sofía Hernández",
            "Carlos Sánchez", "Laura Gómez", "Miguel Díaz", "Elena Moreno", "Diego Muñoz", "Lucía Romero", "Andrés Jiménez",
            "Valeria Pérez", "Javier Ruiz", "Isabel Alonso", "Pablo Gutiérrez", "Claudia Torres", "Alejandro Ortiz", "Sara Navarro",
            "José Martínez", "María González", "David Fernández", "Laura Martín", "Francisco Sánchez",
            "Andrea Pérez", "Daniel Rodríguez", "Paula López", "Ángel Gómez", "Sara Ruiz",
            "Antonio Jiménez", "Eva García", "Rubén Díaz", "Cristina Moreno", "Alberto Vázquez",
            "Luisa Hernández", "Adrián Muñoz", "Raquel Romero", "Gonzalo Torres", "Celia Alonso",
            "Manuel Fernández", "Rosa Martínez", "Jorge López", "Marina Sánchez", "Víctor Rodríguez",
            "Natalia Gómez", "Roberto Pérez", "Carmen Ruiz", "Fernando Jiménez", "Nerea García"
    };

    public static final String[] CALLES = {"Calle del Susurro", "Avenida de los Sueños", "Calle de las Mariposas", "Avenida del Arcoíris",
            "Calle de los Deseos", "Avenida de la Luna", "Calle del Destino", "Avenida de la Esperanza", "Calle del Eco",
            "Avenida de la Imaginación", "Calle del Silencio", "Avenida de los Recuerdos", "Calle del Despertar", "Avenida de la Libertad",
            "Calle del Suspiro", "Avenida de la Aurora", "Calle del Encuentro", "Avenida del Sol", "Calle de la Alegría",
            "Avenida del Corazón"};

    public static final String[] PUESTOS = {"Cajero", "Reponedor", "Encargado de Almacén", "Gerente de Tienda", "Supervisor de Ventas",
            "Asistente de Ventas", "Jefe de Departamento", "Cajero Automático", "Atención al Cliente", "Responsable de Marketing",
            "Analista de Inventario", "Personal de Recursos Humanos", "Gerente de Finanzas", "Auditor Interno", "Jefe de Seguridad",
            "Coordinador de Logística", "Asistente Administrativo", "Analista de Calidad", "Técnico de Mantenimiento",
            "Auxiliar de Limpieza"};

    public static final String[] PRODUCTOS = {"Detergente", "Desinfectante", "Limpiavidrios", "Bolsas de basura",
            "Esponjas", "Martillo", "Destornillador", "Tornillos", "Clavos", "Cinta métrica", "Arroz", "Pasta", "Aceite de oliva",
            "Conservas", "Harina", "Muñeca", "Coche de juguete", "Puzzle", "Pelota", "Juego de construcción", "Sartén", "Cuchillo",
            "Cacerola", "Tabla de cortar", "Espátula", "El principito", "Cien años de soledad", "Harry Potter",
            "Don Quijote de la Mancha", "Orgullo y prejuicio", "Teléfono móvil", "Televisor", "Portátil", "Auriculares", "Cargador"};

    public static String[] opciones = {"\n|| Menú Administrador ||\n", "Elija una de las siguientes opciones: \n",
            "\t1. Insertar producto","\t2. Eliminar producto", "\t3. Listar productos","\t4. Consultar precio de producto",
            "\t5. Dar de alta empleado", "\t6. Dar de baja empleado", "\t7. Cambiar salario de empleado",
            "\t8. Listar todos los empleados", "\t9. Filtar empleado", "\t10. Registrar cliente", "\t11. Eliminar cliente",
            "\t12. Listar todos los clientes", "\t13. Consultar Facturas","\t14. Eliminar coleccion productos",
            "\t15. Consultar empleados por puesto",
            "\t16. Salir\n"
    };

    public static final String PASS = "Supermercado123@";
    public static final String BIENVENIDO = "\n||Bienvenido a Supermercados Dieksim Pachecov||\n";
    public static final String MENU_ADMINISTRADOR = "\t1. Administrador";
    public static final String MENU_CLIENTE = "\t2. Cliente\n";
    public static final String ELEGIR_OPCION = "\nElija una de las siguiente opciones: ";
    public static final String INSERTE_CONTRASENA = "\nInserte una contraseña: ";
    public static final String CONTRASENA_INCORRECTA = "Contraseña incorrecta, inténtelo de nuevo.";
    public static final String FORMATO_CONTRASENA = "Escriba un formato de contraseña";
    public static final String INSERTAR_NOMBRE_PRODUCTO = "Inserte el nombre del producto: ";
    public static final String INSERTAR_CODIGO_PRODUCTO = "Inserte el codigo del producto: ";
    public static final String INSERTAR_PRECIO_PRODUCTO = "Inserte el precio del producto: ";
    public static final String INSERTAR_CATEGORIA_PRODUCTO = "Inserte la categoria del producto: ";
    public static final String PRODUCTO_INSERTADO_CORRECTAMENTE = "Se ha insertado correctamente";
    public static final String PRODUCTO_NO_INSERTADO = "No se ha podido insertar";
    public static final String INSERTE_ID_PRODUCTO = "Inserte el id de producto: ";
    public static final String PRODUCTO_ELIMINADO_CORRECTAMENTE = "Se ha eliminado correctamente";
    public static final String PRODUCTO_NO_ELIMINADO = "No se ha podido eliminar";
    public static final String LISTAR_PRODUCTOS_POR_CATEGORIA = "1. Listar productos por categoría";
    public static final String LISTAR_PRODUCTOS_POR_NOMBRE = "2. Listar productos por nombre";
    public static final String LISTAR_PRODUCTOS_POR_PRECIO = "3. Listar productos por precio";
    public static final String SALIR = "4. Salir";
    public static final String SELECCIONE_OPCION = "Seleccione una opción: ";
    public static final String INGRESE_CATEGORIA = "Ingrese la categoría: ";
    public static final String INGRESE_PRECIO = "Ingrese el precio: ";
    public static final String OPCION_INVALIDA = "Opción inválida. Por favor, seleccione una opción válida.";
    public static final String INSERTE_CODIGO_EMPLEADO = "Inserte el codigo del empleado: ";
    public static final String INSERTE_PUESTO_EMPLEADO = "Inserte el puesto del empleado: ";
    public static final String INSERTE_SUELDO_EMPLEADO = "Inserte el sueldo del empleado: ";
    public static final String EMPLEADO_DADO_ALTA = "Se ha dado de alta";
    public static final String EMPLEADO_NO_DADO_ALTA = "No se ha podido dar de alta";
    public static final String INSERTE_CODIGO_EMPLEADO_BAJA = "Inserte el codigo de empleado: ";
    public static final String EMPLEADO_DADO_BAJA = "Se ha dado de baja correctamente";
    public static final String EMPLEADO_NO_DADO_BAJA = "No se ha podido de baja";
    public static final String INSERTE_NUEVO_SALARIO_EMPLEADO = "Inserte el nuevo salario del  empleado";
    public static final String ACTUALIZANDO_SALARIO = "Actualizando salario...";
    public static final String ORDEN_ALFABETICO = "1. Orden alfabetico";
    public static final String SALARIO = "2. Salario";
    public static final String PUESTO = "Puesto: ";
    public static final String INSERTE_SU_NOMBRE = "Inserte su nombre: ";
    public static final String INSERTE_SU_DNI = "Inserte su DNI: ";
    public static final String INSERTE_SU_CODIGO_POSTAL = "Inserte su codigo postal: ";
    public static final String INSERTE_SU_CALLE = "Inserte su calle: ";
    public static final String INSERTE_NUMERO_CALLE = "Inserte su numero de calle: ";
    public static final String REGISTRO_CORRECTO = "Registro correcto";
    public static final String REGISTRO_NO_CORRECTO = "No ha registrado correctamente";
    public static final String INSERTE_DNI_CLIENTE = "Inserte el DNI del cliente: ";
    public static final String CLIENTE_DADO_BAJA_CORRECTAMENTE = "Se ha dado de baja correctamente";
    public static final String CLIENTE_NO_DADO_BAJA = "No se ha podido de baja";
    public static final String MENU_CLIENTE_HEADER = "\n|| Menú Cliente ||";
    public static final String MENU_CLIENTE_OPCION_1 = "Elija una de las siguientes opciones: ";
    public static final String MENU_CLIENTE_COMPRAR_PRODUCTO = "\t1. Comprar producto";
    public static final String MENU_CLIENTE_CONSULTAR_PRECIO = "\t2. Consultar precio de producto";
    public static final String MENU_CLIENTE_LISTAR_PRODUCTOS = "\t3. Listar productos ordenados";
    public static final String MENU_CLIENTE_REGISTRAR_CLIENTE = "\t4. Registrar cliente";
    public static final String MENU_CLIENTE_SALIR = "\t5. Salir\n";
    public static final String ELIMINAR= "||Eliminar Producto||\n";
    public static final String LISTAR= "=== Listar Productos ===";
    public static final String SALIENDO= "saliendo...";
    public static final String ELIMINAR_COLECCION_PRODUCTOS= "Se ha eliminado correctamente";

}
