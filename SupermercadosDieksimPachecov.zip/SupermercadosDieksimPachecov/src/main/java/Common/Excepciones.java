package Common;

public class Excepciones {

    public static class PuestoException extends Exception{

        public PuestoException(String mensaje){
            super(mensaje);
            
        }

    }

}
