package Common;

public class Comprobaciones {


    public static void comprobarPuesto(String categoria) throws Excepciones.PuestoException {

        boolean error=true;
        for (int i = 0; i < Constantes.PUESTOS.length; i++) {
            if (categoria.equalsIgnoreCase(Constantes.PUESTOS[i])){
                error=false;
            }
        }
        if (error) throw new Excepciones.PuestoException("No existe ese tipo de puesto");
    }

}
