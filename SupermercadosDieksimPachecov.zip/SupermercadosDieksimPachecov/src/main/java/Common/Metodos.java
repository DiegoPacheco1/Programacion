package Common;


import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Metodos {

    public static void esperaRapida(){
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    public static void esperaLenta(){
        try {
            Thread.sleep(800);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    //Agradecimientos a Don Daniel
    public static int leerNumero(int min, int max) {
        Scanner teclado = new Scanner(System.in);
        int num = 0;
        boolean flag = false;

        while (!flag) {
            try {
                num = teclado.nextInt();
                if ((num >= min && num <= max) || (min == max))
                    flag = true;
                else {
                    System.out.println("Introduce un numero entre: " + min + " , " + max);
                }
            } catch (Exception e) {
                System.out.println("Inserte un numero");
            }
            teclado.nextLine();
        }
        return num;
    }

    public static int leerNumero() {
        Scanner teclado = new Scanner(System.in);
        int num = 0;
        boolean flag = false;

        while (!flag) {
            try {
                num = teclado.nextInt();
                if (num>0)
                    flag = true;
                else {
                    System.out.println("Introduce un numero positivo");
                }
            } catch (Exception e) {
                System.out.println("Inserte un numero");
            }
            teclado.nextLine();
        }
        return num;
    }


    public static boolean validarPass(String contrasena) {
        String patron = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$";
        Pattern pattern = Pattern.compile(patron);
        Matcher matcher = pattern.matcher(contrasena);
        return matcher.matches();
    }
}
