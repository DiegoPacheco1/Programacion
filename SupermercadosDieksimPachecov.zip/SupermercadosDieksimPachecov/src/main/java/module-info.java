module ProyectoFruteriaFinal {

    requires lombok;
    requires com.google.gson;
    requires org.apache.logging.log4j;


    opens DaoFicheros to com.google.gson;
    opens Domain to com.google.gson;

}