package Dao;
import DaoFicheros.Ficheros;
import Domain.Producto;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

@Getter
public class Productos {

    private ArrayList<Producto> productos;

    public Productos() {
        productos =(ArrayList<Producto>) Ficheros.leerFicheroProductosBinario();

    }



    public boolean insertarProducto(String nombre, int codigoProducto, String categoria, double precio) {
        return productos.add(new Producto(nombre, codigoProducto, categoria, precio));
    }

    public boolean eliminarProducto(int id) {
        return productos.removeIf(producto -> producto.getCodigoProducto() == id);
    }
    public boolean eliminarcoleccionproductos(){
        return productos.removeAll(productos);
    }

    public List<Producto> listarProductosPorNombre(String nombre) {
        return productos.stream().filter(producto -> producto.getNombre().equalsIgnoreCase(nombre)).toList();
    }

    public List<Producto> listarProductosPorPrecio(int precioMaximo) {
        return productos.stream().filter(producto -> producto.getPrecio() < precioMaximo).toList();
    }

    public double consultarPrecioProducto(String nombreProducto) {
        return productos.stream().filter(producto -> producto.getNombre().equalsIgnoreCase(nombreProducto)).mapToDouble(Producto::getPrecio).findFirst().orElse(0);
    }

    public List<Producto> listarProductosPorCategoria(String categoria) {
        return productos.stream().filter(producto -> producto.getCategoria().equalsIgnoreCase(categoria)).toList();
    }


}
