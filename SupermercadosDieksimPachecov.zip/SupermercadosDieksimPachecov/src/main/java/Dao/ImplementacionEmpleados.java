package Dao;

import Domain.Empleado;
import lombok.Getter;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Getter
public class  ImplementacionEmpleados implements InterfazEmpleados{


    protected Empleados daoEmpleados;

    public ImplementacionEmpleados() {
        this.daoEmpleados = new Empleados();
    }


    @Override
    public boolean darDeAlta(int codigoEmpleado, String puesto, double salario){
            return daoEmpleados.darAlta(codigoEmpleado, puesto, salario);
    }

    @Override
    public boolean darDeBaja(int codigoEmpleado) {
        return daoEmpleados.darbaja(codigoEmpleado);
    }

    @Override
    public boolean cambiarSalario(int codigoEmpleado, int nuevoSalario) {
        return daoEmpleados.cambiarSalario(codigoEmpleado, nuevoSalario);
    }

    @Override
    public Set<Empleado> listarEmpleados() {
        return daoEmpleados.getEmpleados();
    }


    @Override
    public Map<String, List<Empleado>> consultarEmpledosPorPuesto() {
        return daoEmpleados.consultarEmpleadoPorPuesto();
    }
}
