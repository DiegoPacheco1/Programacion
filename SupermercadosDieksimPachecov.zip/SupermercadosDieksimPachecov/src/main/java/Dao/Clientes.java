package Dao;
import DaoFicheros.Ficheros;
import Domain.Cliente;
import Domain.Direccion;
import lombok.Getter;

import java.io.FileNotFoundException;
import java.util.TreeSet;

@Getter
public class Clientes {

    private TreeSet<Cliente> clientes;

    public Clientes() {
        try {
            clientes = (TreeSet<Cliente>) Ficheros.leerFicheroCliente();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

    }


    public boolean registrarClientes(String dni, String nombre, Direccion direccion, int gasto)  {
        return clientes.add(new Cliente(dni, nombre, direccion, gasto));

    }


    public boolean eliminarCliente(String dni) {

        clientes.forEach(cliente -> {
            if (cliente.getDni().equalsIgnoreCase(dni)) clientes.remove(cliente);
        });

        return  true;
    }


}
