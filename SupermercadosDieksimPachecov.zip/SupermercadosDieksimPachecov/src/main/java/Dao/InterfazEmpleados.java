package Dao;

import Domain.Empleado;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface InterfazEmpleados {
    boolean darDeAlta(int codigoEmpleado, String puesto, double salario);
    boolean darDeBaja(int codigoEmpleado);
    boolean cambiarSalario(int codigoEmpleado, int nuevoEmpleado);
    Set<Empleado> listarEmpleados();
    Empleados getDaoEmpleados();
    Map<String, List<Empleado>> consultarEmpledosPorPuesto();
}
