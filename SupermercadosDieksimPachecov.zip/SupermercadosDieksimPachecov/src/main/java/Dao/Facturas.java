package Dao;
import DaoFicheros.Ficheros;
import Domain.Factura;
import lombok.Data;


import java.util.ArrayList;

@Data
public class Facturas {

    private ArrayList<Factura> facturas;


    public Facturas() {

        /*facturas = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            facturas.add(new Factura());
        }*/
        facturas = (ArrayList<Factura>) Ficheros.leerFicheroFacturas();
    }

    public ArrayList<Factura> getFacturas() {
        return facturas;
    }


}
