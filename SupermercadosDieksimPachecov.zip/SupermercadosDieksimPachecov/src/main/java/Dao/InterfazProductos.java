package Dao;

import Domain.Empleado;
import Domain.Factura;
import Domain.Producto;

import java.util.HashSet;
import java.util.List;

public interface InterfazProductos {
    boolean insertarProducto(String nombre, int codigoProducto, String categoria, double precio);
    boolean eliminarProducto(int id);
    boolean eliminarcoleccionproductos();
    List<Producto> listarProductosPorCategoria(String categoria);
    List<Producto> listarProductosPorNombre(String nombre);
    List<Producto> listarProductosPorPrecio(int precioMinimo);
    Factura comprarproducto(String nombreProducto);
    double consultarPrecioProducto(String nombreProducto);//falta en el taiga
    Productos getDaoProductos();
}
