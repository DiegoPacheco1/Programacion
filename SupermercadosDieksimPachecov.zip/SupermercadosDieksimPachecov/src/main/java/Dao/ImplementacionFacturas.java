package Dao;

import Domain.Factura;
import lombok.Data;
import lombok.Getter;

@Data
public class ImplementacionFacturas implements InterfazFacturas{

    protected Facturas daoFacturas;

    public ImplementacionFacturas() {
        this.daoFacturas = new Facturas();
    }


}
