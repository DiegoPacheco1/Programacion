package Dao;
import Domain.Factura;
import Domain.Producto;
import lombok.Getter;

import java.util.List;

@Getter
public class ImplementacionProductos implements InterfazProductos{

    protected Productos daoProductos;


    public ImplementacionProductos() {
        this.daoProductos = new Productos();
    }


    @Override
    public boolean insertarProducto(String nombre, int codigoProducto, String categoria, double precio) {
        return daoProductos.insertarProducto(nombre,codigoProducto,categoria,precio);
    }

    @Override
    public boolean eliminarProducto(int id) {
        return daoProductos.eliminarProducto(id);
    }



    @Override
    public boolean eliminarcoleccionproductos() {
        return daoProductos.eliminarcoleccionproductos();
    }

    @Override
    public List<Producto> listarProductosPorCategoria(String categoria) {
        return daoProductos.listarProductosPorCategoria(categoria);
    }


    @Override
    public List<Producto> listarProductosPorNombre(String nombre) {
        return daoProductos.listarProductosPorNombre(nombre);
    }

    @Override
    public List<Producto> listarProductosPorPrecio(int precioMaximo) {
        return daoProductos.listarProductosPorPrecio(precioMaximo);
    }

    @Override
    public Factura comprarproducto(String nombreProducto) {
        return null;
    }

    @Override
    public double consultarPrecioProducto(String nombreProducto) {
        return daoProductos.consultarPrecioProducto(nombreProducto);
    }

}
