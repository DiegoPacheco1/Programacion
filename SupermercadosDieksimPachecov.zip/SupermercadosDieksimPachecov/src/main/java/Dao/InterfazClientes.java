package Dao;

import Domain.Cliente;
import Domain.Direccion;

import java.util.Set;

public interface InterfazClientes {
    boolean eliminarCliente(String dni);
    Set<Cliente> listarClientes();
    Clientes getDaoClientes();
    boolean registrarCliente(String dni, String nombre, Direccion direccion, int gasto);
}
