package Dao;
import Domain.Cliente;
import Domain.Direccion;
import java.util.Set;

public class ImplementacionClientes implements InterfazClientes{

    protected Clientes daoClientes;


    public ImplementacionClientes() {
        this.daoClientes = new Clientes();
    }


    @Override
    public boolean registrarCliente(String dni, String nombre, Direccion direccion, int gasto) {
        return daoClientes.registrarClientes(dni, nombre, direccion, gasto);
    }

    @Override
    public boolean eliminarCliente(String dni) {
        return daoClientes.eliminarCliente(dni);
    }

    @Override
    public Set<Cliente> listarClientes() {
        return daoClientes.getClientes();
    }


    public Clientes getDaoClientes() {
        return daoClientes;
    }


}
