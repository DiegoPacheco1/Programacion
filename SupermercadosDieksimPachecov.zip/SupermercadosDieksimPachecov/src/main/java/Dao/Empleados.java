package Dao;
import Common.Excepciones;
import DaoFicheros.Ficheros;
import Domain.Empleado;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


public class Empleados {

    private HashSet<Empleado> empleados;

    public Empleados() {
//        empleados = new HashSet<>();
//        for (int i = 0; i < 30; i++) {
//            empleados.add(new Empleado());
//        }


       empleados = Ficheros.leerFicheroEmpleado();
    }

    public HashSet<Empleado> getEmpleados() {
        return empleados;
    }


    public boolean darAlta(int codigoEmpleado, String puesto, double salario) {

        boolean correcto;

        try {
            correcto = empleados.add(new Empleado(puesto, salario, codigoEmpleado));
        } catch (Excepciones.PuestoException e) {
            throw new RuntimeException(e);
        }

        return correcto;

    }

    public boolean cambiarSalario(int codigoempleado, int nuevoSalario) {

        empleados.stream().filter(empleado -> empleado.getCodigoEmpleado() == codigoempleado).forEach(empleado -> empleado.setSalario(nuevoSalario));

        return true;
    }

    public boolean darbaja(int codigoEmpleado) {

        return empleados.removeIf(empleado -> empleado.getCodigoEmpleado() == codigoEmpleado);

    }

    public Map<String, List<Empleado>> consultarEmpleadoPorPuesto() {
        return empleados.stream().collect(Collectors.groupingBy(Empleado::getPuesto));
    }
}
