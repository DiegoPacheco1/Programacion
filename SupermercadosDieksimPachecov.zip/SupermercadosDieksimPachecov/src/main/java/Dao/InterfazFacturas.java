package Dao;

import Domain.Factura;

public interface InterfazFacturas {


    Facturas getDaoFacturas();
}
