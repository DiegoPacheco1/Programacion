package Domain;
import Common.Constantes;
import lombok.Data;
import java.util.Objects;
import java.util.Random;


@Data
public abstract class Persona {

    protected String dni;
    protected String nombre;
    protected Direccion direccion;

    public Persona(String dni, String nombre, Direccion direccion) {
        this.dni = dni;
        this.nombre = nombre;
        this.direccion = direccion;
    }

    public Persona(){
        Random random= new Random();
        this.dni=  String.valueOf(random.nextInt(1396338, 9273654))+(char) ('A' + random.nextInt(0,26));
        this.nombre= Constantes.NOMBRES[random.nextInt(0,49)];
        this.direccion=new Direccion();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Persona persona = (Persona) o;
        return Objects.equals(dni, persona.dni);
    }

    @Override
    public int hashCode() {
        return Objects.hash(dni);
    }
}
