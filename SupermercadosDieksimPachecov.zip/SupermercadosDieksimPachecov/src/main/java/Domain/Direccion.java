package Domain;

import Common.Constantes;
import lombok.Data;

import java.util.Random;

@Data
public class Direccion {

    private String codigoPostal;
    private String nombreCalle;
    private int numeroCalle;


    public Direccion(String codigoPostal, String nombreCalle, int numeroCalle) {
        this.codigoPostal = codigoPostal;
        this.nombreCalle = nombreCalle;
        this.numeroCalle = numeroCalle;
    }

    public Direccion(){
        Random random = new Random();
        this.codigoPostal=String.valueOf(random.nextInt(28012,28089));
        this.nombreCalle= Constantes.CALLES[random.nextInt(0,19)];
        this.numeroCalle= random.nextInt(0,300);
    }

    public Direccion(String lineaFichero){
        String[] arrayFichero=lineaFichero.split("_");
        this.codigoPostal=arrayFichero[0];
        this.nombreCalle=arrayFichero[1];
        this.numeroCalle=Integer.parseInt(arrayFichero[2]);
    }

    @Override
    public String toString() {
        return "Direccion{" +
                "codigoPostal='" + codigoPostal + '\'' +
                ", nombreCalle='" + nombreCalle + '\'' +
                ", numeroCalle=" + numeroCalle +
                '}';
    }

    public String toStringFichero(){
        return codigoPostal+"_"+nombreCalle+"_"+numeroCalle;
    }
}
