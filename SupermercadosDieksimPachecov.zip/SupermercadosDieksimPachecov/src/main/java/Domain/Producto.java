package Domain;

import Common.Constantes;
import lombok.Data;
import lombok.Getter;

import java.io.Serializable;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;


@Data
public class Producto implements Serializable {

    private String nombre;
    private int codigoProducto;
    private String categoria;
    private double precio;


    public Producto(String nombre, int codigoProducto, String categoria, double precio) {
        this.nombre = nombre;
        this.codigoProducto = codigoProducto;
        this.categoria = categoria;
        this.precio = precio;
    }


    public Producto() {

        Random random = new Random();
        double asignarCategoria = ThreadLocalRandom.current().nextDouble(0, 19);

        this.codigoProducto = random.nextInt(0, 200);
        this.nombre = Constantes.PRODUCTOS[(int) asignarCategoria];

        if (asignarCategoria < 5) {
            this.categoria = "Limpieza";
            this.precio = (double) Math.round(random.nextDouble(2, 5) * 100) / 100;
        } else if (asignarCategoria < 10) {
            this.categoria = "Ferreteria";
            this.precio = (double) Math.round(random.nextDouble(10, 15) * 100) / 100;
        } else if (asignarCategoria < 15) {
            this.categoria = "Alimentación";
            this.precio = (double) Math.round(random.nextDouble(1, 5) * 100) / 100;
        } else if (asignarCategoria < 20) {
            this.categoria = "Juguetes";
            this.precio = (double) Math.round(random.nextDouble(20, 30) * 100) / 100;
        } else if (asignarCategoria < 25) {
            this.categoria = "Utensilios de cocina";
            this.precio = (double) Math.round(random.nextDouble(5, 10) * 100) / 100;
        } else if (asignarCategoria < 30) {
            this.categoria = "Libros";
            this.precio = (double) Math.round(random.nextDouble(20, 30) * 100) / 100;
        } else {
            this.categoria = "Electrónica";
            this.precio = (double) Math.round(random.nextDouble(150, 500) * 100) / 100;
        }
    }

    public Producto(String lineaFichero) {
        String[] ficheroArray = lineaFichero.split(";");
        this.precio =Integer.parseInt(ficheroArray[3]);
        this.codigoProducto=Integer.parseInt(ficheroArray[0]);
        this.categoria=ficheroArray[2];
        this.nombre = ficheroArray[1];
    }


    @Override
    public String toString() {
        return "nombre='" + nombre + '\'' +
                ", codigoProducto=" + codigoProducto +
                ", categoria='" + categoria + '\'' +
                ", precio=" + precio
               ;
    }


}
