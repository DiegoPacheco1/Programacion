package Domain;
import Common.Comprobaciones;
import Common.Constantes;
import Common.Excepciones;
import DaoFicheros.Ficheros;
import lombok.Data;


import java.util.Objects;
import java.util.Random;

@Data
public class Empleado extends Persona {


    private String puesto;
    private double salario;
    private int codigoEmpleado;


    public Empleado(String puesto, double salario, int codigoEmpleado) throws Excepciones.PuestoException {
        super();
        Comprobaciones.comprobarPuesto(puesto);
        this.puesto = puesto;
        this.salario = salario;
        this.codigoEmpleado = codigoEmpleado;
    }

    public Empleado() {
        super();
        Random random = new Random();
        this.puesto = Constantes.PUESTOS[random.nextInt(0, 19)];
        this.salario = random.nextInt(1100, 10000);
        this.codigoEmpleado = random.nextInt(0, 200);
    }

    public Empleado(String lineaFichero) {
        String[] ficheroArray = lineaFichero.split(";");
        this.dni = ficheroArray[0];
        this.nombre = ficheroArray[1];
        this.puesto = ficheroArray[2];
        ficheroArray[3]=ficheroArray[3].substring(0,ficheroArray[3].length()-1);
        this.salario = Double.parseDouble(ficheroArray[3]);
        this.codigoEmpleado = (int) Double.parseDouble(ficheroArray[4]);
        this.direccion = new Direccion(ficheroArray[5]);
    }




    @Override
    public String toString() {
        return "puesto='" + puesto + '\'' +
                ", salario=" + salario + "€" +
                ", codigoEmpleado=" + codigoEmpleado +
               super.toString();
    }

    public String toStringFicheros() {
        return dni + ";" + nombre + ";" + puesto + ";" + salario + "€;" + codigoEmpleado + ";" + direccion.toStringFichero();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Empleado empleado = (Empleado) o;
        return salario == empleado.salario && codigoEmpleado == empleado.codigoEmpleado && Objects.equals(puesto, empleado.puesto);
    }


    @Override
    public int hashCode() {
        return Objects.hash(puesto, salario, codigoEmpleado);
    }
}
