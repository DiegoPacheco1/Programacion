package Domain;
import lombok.Data;
import lombok.EqualsAndHashCode;
import java.io.Serializable;
import java.util.Random;

@EqualsAndHashCode(callSuper = true)
@Data
public class Cliente extends Persona implements Comparable<Cliente>, Serializable {


    private double gasto;


    public Cliente(String dni, String nombre, Direccion direccion, double gasto) {
        super(dni, nombre, direccion);
        this.gasto = gasto;
    }
    


    public Cliente() {
        super();
        Random random = new Random();
        gasto = (double) Math.round(random.nextDouble(2, 10000) * 100) / 100;

    }

    public Cliente(String lineaFichero) {
        String[] ficheroArray = lineaFichero.split(";");
        this.dni=ficheroArray[0];
        this.nombre=ficheroArray[1];
        ficheroArray[2]=ficheroArray[2].substring(0,ficheroArray[2].length()-1);
        this.gasto=Double.parseDouble(ficheroArray[2]);
        this.direccion=new Direccion(ficheroArray[3]);
    }



    @Override
    public String toString() {
        return  "gasto=" + gasto + "€" + super.toString();

    }

    public String toStringFicheros() {
        return dni + ";" + nombre + ";" + gasto + "€;" + direccion.toStringFichero();
    }


    @Override
    public int compareTo(Cliente o) {
        return nombre.compareTo(o.nombre);
    }
}
