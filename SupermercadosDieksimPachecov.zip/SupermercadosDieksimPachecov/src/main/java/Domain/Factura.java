package Domain;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;

@Data
public class Factura implements Serializable {

    private int numReferencia;
    private LocalDate fechaEmision;
    private LocalDateTime horaEmision;
    private Cliente cliente;
    private double precioTotal;
    private ArrayList<Producto> productosFactura;

    public Factura(int numReferencia, LocalDate fechaEmision, LocalDateTime horaEmision, Cliente cliente, double precioTotal, ArrayList<Producto> productosFactura) {
        this.numReferencia = numReferencia;
        this.fechaEmision = fechaEmision;
        this.horaEmision = horaEmision;
        this.cliente = cliente;
        this.precioTotal = precioTotal;
        this.productosFactura = productosFactura;
    }

    public Factura(int numReferencia, Cliente cliente, int precioTotal, ArrayList<Producto> productosFactura) {
        this.numReferencia = numReferencia;
        this.fechaEmision = LocalDate.now();
        this.horaEmision = LocalDateTime.now();
        this.cliente = cliente;
        this.precioTotal = precioTotal;
        this.productosFactura = productosFactura;
    }

    public Factura() {
        productosFactura = new ArrayList<>();
        Random random = new Random();
        int randomProductos = random.nextInt(0, 10);
        for (int i = 0; i < randomProductos; i++) {
            Producto producto = new Producto();
            this.productosFactura.add(new Producto());
            this.precioTotal += producto.getPrecio();

        }

        this.numReferencia = random.nextInt(0, 50);
        this.fechaEmision = LocalDate.now();
        this.horaEmision = LocalDateTime.now();
        this.cliente = new Cliente();


    }


    @Override
    public String toString() {
        return "Factura{" +
                "numReferencia=" + numReferencia +
                ", fechaEmision=" + fechaEmision +
                ", horaEmision=" + horaEmision +
                ", cliente=" + cliente +
                ", precioTotal=" + precioTotal +
                ", productosFactura=" + productosFactura +
                '}';
    }

    public String toStringFicheros() {
        return numReferencia + ";" + fechaEmision + ";" + horaEmision + ";" + cliente.toStringFicheros() +
                ";" + precioTotal + ";" + productosFactura;

    }


}
