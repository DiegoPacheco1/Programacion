package UI;

import Dao.Clientes;
import Dao.Empleados;
import Dao.Facturas;
import Dao.Productos;
import DaoFicheros.Ficheros;

import java.io.FileNotFoundException;
import java.io.IOException;

public class MainFicheros {

    public static void main(String[] args) {


     Empleados empleados = new Empleados();
//        try {
//            Ficheros.ecribirFicheroEmpleado(empleados.getEmpleados());
//        } catch (FileNotFoundException e) {
//            throw new RuntimeException(e);
//        }
//        Clientes clientes = new Clientes();
//        try {
//            Ficheros.escribirFicheroClientes(clientes.getClientes());
//        } catch (FileNotFoundException e) {
//            throw new RuntimeException(e);
//        }


//        Facturas facturas = new Facturas();
//
//        try {
//            Ficheros.escribirFicheroFacturasBinario(facturas.getFacturas());
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//

 //       Facturas facturas = new Facturas();

        //Ficheros.escribirFicherosFactura(facturas.getFacturas());

//        try {
//            Ficheros.escribirFicheroFacturaBinario(facturas.getFacturas());
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }

//
//        Empleados empleados= new Empleados();

//      Productos productos=new Productos();

//        try {
//            Ficheros.escribirFicheroProductosBinario(productos.getProductos());
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
        System.out.println();
    }


}
