package UI;
import Common.Constantes;
import Common.Metodos;
import DaoFicheros.Ficheros;
import Domain.*;
import Service.ImplementacionGestion;
import Service.InterfazGestion;

import java.util.*;


public class GestionArranque {


    protected InterfazGestion service;
    private String pass = Constantes.PASS;


    public GestionArranque() {
        this.service = new ImplementacionGestion();
    }


    public void arranqueAplicacion() {

        Scanner teclado = new Scanner(System.in);

        System.out.println(Constantes.BIENVENIDO);
        System.out.println(Constantes.MENU_ADMINISTRADOR);
        System.out.println(Constantes.MENU_CLIENTE);
        System.out.print(Constantes.ELEGIR_OPCION);


        int opcion = Metodos.leerNumero(1, 2);

        if (opcion==1){

            boolean passCorrecta=false;
            while (!passCorrecta){
                System.out.print(Constantes.INSERTE_CONTRASENA);
                String contrasena = teclado.nextLine();
                if (Metodos.validarPass(contrasena)) {
                    passCorrecta = contrasena.equals(pass);
                    if (passCorrecta) {
                        menuAdministrador();
                    } else {
                        System.out.println(Constantes.CONTRASENA_INCORRECTA);
                    }
                } else {
                    System.out.println(Constantes.FORMATO_CONTRASENA);
                }
                passCorrecta= contrasena.equals(pass);
            }
        }else menuCliente();






    }


    private void menuAdministrador() {
        Scanner teclado = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {

            Arrays.stream(Constantes.opciones).forEach(System.out::println);

            int opcion = Metodos.leerNumero(1, 16);

            switch (opcion) {
                case 1:

                    teclado.nextLine();
                    System.out.println(Constantes.INSERTAR_NOMBRE_PRODUCTO);
                    System.out.print(Constantes.INSERTAR_NOMBRE_PRODUCTO);
                    String nombreP = teclado.nextLine();
                    System.out.print(Constantes.INSERTAR_CODIGO_PRODUCTO);
                    int codigoP = Metodos.leerNumero();
                    System.out.print(Constantes.INSERTAR_PRECIO_PRODUCTO);
                    double precioP = teclado.nextDouble();
                    teclado.nextLine();
                    System.out.print(Constantes.INSERTAR_CATEGORIA_PRODUCTO);
                    String categoriaP = teclado.nextLine();
                    if (service.insertarProducto(nombreP, codigoP, categoriaP, precioP))
                        System.out.println(Constantes.PRODUCTO_INSERTADO_CORRECTAMENTE);
                    else
                        System.out.println(Constantes.PRODUCTO_NO_INSERTADO);


                    break;
                case 2:
                    System.out.println(Constantes.ELIMINAR);
                    System.out.print(Constantes.INSERTE_ID_PRODUCTO);
                    int idprod = Metodos.leerNumero();
                    if (service.eliminarProducto(idprod))
                        System.out.println(Constantes.PRODUCTO_ELIMINADO_CORRECTAMENTE);
                    else
                        System.out.println(Constantes.PRODUCTO_NO_ELIMINADO);
                    break;
                case 3:
                    boolean exit = false;
                    do {
                        System.out.println(Constantes.LISTAR);
                        System.out.println(Constantes.LISTAR_PRODUCTOS_POR_CATEGORIA);
                        System.out.println(Constantes.LISTAR_PRODUCTOS_POR_NOMBRE);
                        System.out.println(Constantes.LISTAR_PRODUCTOS_POR_PRECIO);
                        System.out.println(Constantes.SALIR);
                        System.out.print(Constantes.SELECCIONE_OPCION);
                        opcion = Metodos.leerNumero(1, 4);
                        teclado.nextLine();


                        switch (opcion) {
                            case 1:
                                System.out.print(Constantes.INGRESE_CATEGORIA);
                                String categoria = teclado.nextLine();
                                service.listarProductosPorCategoria(categoria).forEach(producto -> {
                                    Metodos.esperaRapida();
                                    System.out.println(producto);
                                });
                                break;
                            case 2:
                                System.out.print(Constantes.INSERTAR_NOMBRE_PRODUCTO);
                                String nombreprod = teclado.nextLine();
                                service.listarProductosPorNombre(nombreprod).forEach(producto -> {
                                    Metodos.esperaRapida();
                                    System.out.println(producto);
                                });
                                Metodos.esperaLenta();
                                break;
                            case 3:
                                System.out.print(Constantes.INGRESE_PRECIO);
                                int precio = teclado.nextInt();
                                teclado.nextLine(); // Consumir el salto de línea pendiente
                                service.listarProductosPorPrecio(precio).forEach(System.out::println);
                                break;
                            case 4:
                                exit = true;
                                System.out.println(Constantes.SALIENDO);
                                break;
                            default:
                                System.out.println(Constantes.OPCION_INVALIDA);
                        }

                    } while (!exit);
                    break;
                case 4:

                    System.out.print(Constantes.INSERTAR_NOMBRE_PRODUCTO);
                    String nombreproducto = teclado.nextLine();
                    System.out.println(service.consultarPrecioProducto(nombreproducto) + "€");
                    break;
                case 5:

                    System.out.print(Constantes.INSERTE_CODIGO_EMPLEADO);
                    int codigo = Metodos.leerNumero();
                    teclado.nextLine();
                    System.out.print(Constantes.INSERTE_PUESTO_EMPLEADO);
                    String puesto = teclado.nextLine();
                    System.out.print(Constantes.INSERTE_SUELDO_EMPLEADO);
                    double sueldo = teclado.nextDouble();
                    if (service.darDeAlta(codigo, puesto, sueldo))
                        System.out.println(Constantes.EMPLEADO_DADO_ALTA);
                    else
                        System.out.println(Constantes.EMPLEADO_NO_DADO_ALTA);
                    break;
                case 6:

                    System.out.print(Constantes.INSERTE_CODIGO_EMPLEADO_BAJA);
                    int codigoEmp = Metodos.leerNumero();
                    if (service.darDeBaja(codigoEmp))
                        System.out.println(Constantes.EMPLEADO_DADO_BAJA);
                    else
                        System.out.println(Constantes.EMPLEADO_NO_DADO_BAJA);
                    break;
                case 7:

                    System.out.print(Constantes.INSERTE_CODIGO_EMPLEADO);
                    codigoEmp = Metodos.leerNumero();
                    System.out.println(Constantes.INSERTE_NUEVO_SALARIO_EMPLEADO);
                    int nuevoSalario = Metodos.leerNumero();
                    service.cambiarSalario(codigoEmp, nuevoSalario);
                    System.out.println(Constantes.ACTUALIZANDO_SALARIO);
                    Metodos.esperaLenta();
                    break;

                case 8:
                    int num = 1;
                    for (Empleado empleado : service.listarEmpleados()) {
                        Metodos.esperaRapida();
                        System.out.println(num + ". " + empleado);
                        num++;
                    }
                    Metodos.esperaLenta();
                    break;
                case 9:
                    System.out.println(Constantes.ORDEN_ALFABETICO);
                    System.out.println(Constantes.SALARIO);
                    opcion = Metodos.leerNumero(1, 2);
                    switch (opcion) {
                        case 1:
                            service.getDaoEmpleados().getDaoEmpleados().getEmpleados().stream().
                                    sorted(Comparator.comparing(Empleado::getNombre).thenComparing(Empleado::getCodigoEmpleado)).
                                    forEach(System.out::println);
                            break;
                        case 2:
                            service.getDaoEmpleados().getDaoEmpleados().getEmpleados().stream().
                                    sorted(Comparator.comparing(Empleado::getSalario)).
                                    forEach(System.out::println);
                            break;
                    }
                    break;
                case 10:
                    teclado.nextLine();
                    System.out.print(Constantes.INSERTE_SU_NOMBRE);
                    String nombreC = teclado.nextLine();
                    System.out.print(Constantes.INSERTE_SU_DNI);
                    String dni = teclado.nextLine();
                    System.out.print(Constantes.INSERTE_SU_CODIGO_POSTAL);
                    String cp = teclado.nextLine();
                    System.out.print(Constantes.INSERTE_SU_CALLE);
                    String calle = teclado.nextLine();
                    System.out.print(Constantes.INSERTE_NUMERO_CALLE);
                    int numCalle = Metodos.leerNumero();

                    if (service.registrarCliente(dni, nombreC, new Direccion(cp, calle, numCalle), 0))
                        System.out.println(Constantes.REGISTRO_CORRECTO);
                    else
                        System.out.println(Constantes.REGISTRO_NO_CORRECTO);
                    Metodos.esperaLenta();
                    break;

                case 11:

                    System.out.print(Constantes.INSERTE_DNI_CLIENTE);
                     dni = teclado.nextLine();

                    if (service.eliminarCliente(dni))
                        System.out.println(Constantes.CLIENTE_DADO_BAJA_CORRECTAMENTE);
                    else
                        System.out.println(Constantes.CLIENTE_NO_DADO_BAJA);
                    break;
                case 12:
                    num = 1;
                    for (Cliente cliente : service.listarClientes()) {
                        Metodos.esperaLenta();
                        System.out.println(num + ". " + cliente);
                        num++;
                    }
                    Metodos.esperaLenta();
                    break;
                case 13:

                    service.getDaoFacturas().getDaoFacturas().getFacturas().stream().sorted(Comparator.comparing(Factura::getFechaEmision)).forEach(System.out::println);
                    break;
                case 14:
                    if (service.eliminarcoleccionproductos())
                        System.out.println(Constantes.ELIMINAR_COLECCION_PRODUCTOS);
                    else
                        System.out.println(Constantes.PRODUCTO_NO_ELIMINADO);
                    Metodos.esperaLenta();
                    Metodos.esperaLenta();
                    break;
                case 15:

                    Map<String, List<Empleado>> empleadosPuesto = service.consultarEmpledosPorPuesto();
                    empleadosPuesto.forEach((s, empleados) -> {
                        System.out.println(Constantes.PUESTO + s);
                        empleados.forEach(empleado -> System.out.println("\t" + empleado.getNombre()));
                    });
                    break;
                case 16:
                    salir = true;
                    System.out.println(Constantes.SALIENDO);
                    Metodos.esperaLenta();
                    Metodos.esperaLenta();
                    break;

            }

            Ficheros.reescribirTodosLosFicheros(service);


        }
    }


    private void menuCliente() {
        Scanner teclado = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println(Constantes.MENU_CLIENTE_HEADER);
            System.out.println(Constantes.MENU_CLIENTE_OPCION_1);
            System.out.println(Constantes.MENU_CLIENTE_COMPRAR_PRODUCTO);
            System.out.println(Constantes.MENU_CLIENTE_CONSULTAR_PRECIO);
            System.out.println(Constantes.MENU_CLIENTE_LISTAR_PRODUCTOS);
            System.out.println(Constantes.MENU_CLIENTE_REGISTRAR_CLIENTE);
            System.out.println(Constantes.MENU_CLIENTE_SALIR);

            int opcion = Metodos.leerNumero(1, 5);
            teclado.nextLine();

            switch (opcion) {
                case 1:
                    // Llamar al método para comprar producto
                    break;
                case 2:

                    System.out.print(Constantes.INSERTAR_NOMBRE_PRODUCTO);
                    String nombreproducto = teclado.nextLine();
                    System.out.println(service.consultarPrecioProducto(nombreproducto) + "€");
                    break;
                case 3:
                    boolean exit = false;
                    do {
                        System.out.println(Constantes.LISTAR_PRODUCTOS_POR_CATEGORIA);
                        System.out.println(Constantes.LISTAR_PRODUCTOS_POR_NOMBRE);
                        System.out.println(Constantes.LISTAR_PRODUCTOS_POR_PRECIO);
                        System.out.println(Constantes.SALIR);
                        System.out.print(Constantes.SELECCIONE_OPCION);
                        opcion = Metodos.leerNumero(1, 4);
                        teclado.nextLine();

                        switch (opcion) {
                            case 1:
                                System.out.print(Constantes.INGRESE_CATEGORIA);
                                String categoria = teclado.nextLine();
                                service.listarProductosPorCategoria(categoria).forEach(producto -> {
                                    Metodos.esperaRapida();
                                    System.out.println(producto);
                                });
                                break;
                            case 2:
                                System.out.print(Constantes.INSERTAR_NOMBRE_PRODUCTO);
                                String nombreprod = teclado.nextLine();
                                service.listarProductosPorNombre(nombreprod).forEach(producto -> {
                                    Metodos.esperaRapida();
                                    System.out.println(producto);
                                });
                                Metodos.esperaLenta();
                                break;
                            case 3:
                                System.out.print(Constantes.INGRESE_PRECIO);
                                int precio = Metodos.leerNumero();
                                service.listarProductosPorPrecio(precio).forEach(System.out::println);
                                break;
                            case 4:
                                exit = true;
                                System.out.println(Constantes.SALIENDO);
                                break;
                            default:
                                System.out.println(Constantes.OPCION_INVALIDA);
                                break;
                        }
                    } while (!exit);
                    break;
                case 4:
                    teclado.nextLine();
                    System.out.print(Constantes.INSERTE_SU_NOMBRE);
                    String nombreC = teclado.nextLine();
                    System.out.print(Constantes.INSERTE_SU_DNI);
                    String dni = teclado.nextLine();
                    System.out.print(Constantes.INSERTE_SU_CODIGO_POSTAL);
                    String cp = teclado.nextLine();
                    System.out.print(Constantes.INSERTE_SU_CALLE);
                    String calle = teclado.nextLine();
                    System.out.print(Constantes.INSERTE_NUMERO_CALLE);
                    int numCalle = Metodos.leerNumero();

                    if (service.registrarCliente(dni, nombreC, new Direccion(cp, calle, numCalle), 0))
                        System.out.println(Constantes.REGISTRO_CORRECTO);
                    else
                        System.out.println(Constantes.REGISTRO_NO_CORRECTO);
                    Metodos.esperaLenta();
                    break;
                case 5:
                    salir = true;
                    System.out.println(Constantes.SALIENDO);
                    break;
                default:
                    System.out.println(Constantes.OPCION_INVALIDA);
                    break;
            }
        }
    }

}

