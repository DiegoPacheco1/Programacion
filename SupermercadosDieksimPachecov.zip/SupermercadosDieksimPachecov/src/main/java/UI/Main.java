package UI;
public class Main {

    public static void main(String[] args) {

        GestionArranque ga = new GestionArranque();
        ga.arranqueAplicacion();

    }

}
