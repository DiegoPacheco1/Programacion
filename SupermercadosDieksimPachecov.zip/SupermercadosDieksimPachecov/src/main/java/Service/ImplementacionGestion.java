package Service;
import Dao.*;
import Domain.*;
import lombok.Getter;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ImplementacionGestion implements InterfazGestion{

    @Getter
    protected InterfazClientes daoClientes;
    @Getter
    protected InterfazProductos daoProductos;
    @Getter
    protected InterfazEmpleados daoEmpleados;
    protected InterfazFacturas daoFacturas;

    public ImplementacionGestion() {
        this.daoClientes = new ImplementacionClientes();
        this.daoProductos = new ImplementacionProductos();
        this.daoEmpleados = new ImplementacionEmpleados();
        this.daoFacturas =  new ImplementacionFacturas();
    }

    @Override
    public boolean eliminarcoleccionproductos() {
        return daoProductos.eliminarcoleccionproductos();
    }

    @Override
    public boolean insertarProducto(String nombre, int codigoProducto, String categoria, double precio) {
        return daoProductos.insertarProducto(nombre,codigoProducto,categoria,precio);
    }

    @Override
    public boolean eliminarProducto(int id) {

        return daoProductos.eliminarProducto(id);
    }

    @Override
    public List<Producto> listarProductosPorCategoria(String categoria) {
        return daoProductos.listarProductosPorCategoria(categoria);
    }

    @Override
    public List<Producto> listarProductosPorNombre(String nombre) {

        return daoProductos.listarProductosPorNombre(nombre);
    }

    @Override
    public List<Producto> listarProductosPorPrecio(int precio) {
        return daoProductos.listarProductosPorPrecio(precio);
    }

    @Override
    public Factura comprarproducto(String nombreProducto) {
        return null;
    }


    @Override
    public double consultarPrecioProducto(String nombreProducto) {
        return daoProductos.consultarPrecioProducto(nombreProducto);
    }

    @Override
    public boolean darDeAlta(int codigoEmpleado, String puesto, double salario){
        return daoEmpleados.darDeAlta(codigoEmpleado,puesto,salario);
    }

    @Override
    public boolean darDeBaja(int codigoEmpleado) {
        return daoEmpleados.darDeBaja(codigoEmpleado);
    }

    @Override
    public boolean cambiarSalario(int codigoEmpleado, int nuevoSalario) {
        return daoEmpleados.cambiarSalario(codigoEmpleado, nuevoSalario);
    }

    @Override
    public Set<Empleado> listarEmpleados() {
        return daoEmpleados.listarEmpleados();
    }

    @Override
    public Map<String, List<Empleado>> consultarEmpledosPorPuesto() {
        return daoEmpleados.consultarEmpledosPorPuesto();
    }



    @Override
    public boolean registrarCliente(String dni, String nombre, Direccion direccion, int gasto) {
        return false;
    }


    @Override
    public boolean eliminarCliente(String dni) {
        return daoClientes.eliminarCliente(dni);
    }

    @Override
    public Set<Cliente> listarClientes() {
        return daoClientes.listarClientes();
    }


    @Override
    public InterfazFacturas getDaoFacturas() {
        return daoFacturas;
    }


}
